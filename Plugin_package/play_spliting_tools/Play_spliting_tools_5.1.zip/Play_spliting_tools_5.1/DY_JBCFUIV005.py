#!/usr/bin/env python
# -*- coding: utf-8 -*-
###################################################################
# Author: Zhao Haoyu
# Date  : 2022.1.5
# 当前版本为适合V18版本宏的程序
###################################################################

import os
import docx
import re
import xlsxwriter

from Qt.QtWidgets import QApplication
from Qt.QtWidgets import QMessageBox
from Qt import QtCore
from Qt import QtWidgets
from docx.enum.text import WD_COLOR_INDEX


from dayu_widgets.field_mixin import MFieldMixin
from dayu_widgets.browser import MDragFolderButton
from dayu_widgets.label import MLabel
from dayu_widgets.divider import MDivider
from dayu_widgets.spin_box import MSpinBox
from dayu_widgets.push_button import MPushButton
from dayu_widgets.item_view import MListView
from dayu_widgets.item_model import MSortFilterModel
from dayu_widgets.item_model import MTableModel

header_list = [
    {
        "key": "docx_name",
        "checkable": True,
    }
]

class ScriptSplit(QtWidgets.QWidget, MFieldMixin):
    def __init__(self, parent=None):
        super(ScriptSplit, self).__init__(parent)
        self.setWindowTitle(u"天工剧本拆分工具")
        self._init_ui()

    def _init_ui(self):
        browser_1 = MDragFolderButton()
        self.label_1 = MLabel()
        self.label_1.set_elide_mode(QtCore.Qt.ElideMiddle)
        browser_1.sig_folder_changed.connect(self.label_1.setText)
        browser_1.sig_folder_changed.connect(self.GetFolder)

        lay_1 = QtWidgets.QGridLayout()
        lay_1.addWidget(browser_1)
        lay_1.addWidget(self.label_1)

        self.model_1 = MTableModel()
        self.model_1.set_header_list(header_list)
        model_sort = MSortFilterModel()
        model_sort.setSourceModel(self.model_1)
        table_default = MListView()
        table_default.setModel(model_sort)
        table_default.setMinimumSize(200, 200)

        lable_2 =MLabel(u"单集时长:")
        self.spin_box = MSpinBox()
        self.spin_box.setRange(0, 9999)
        self.spin_box.setValue(40)

        lay_2 = QtWidgets.QHBoxLayout()
        lay_2.addWidget(lable_2)
        lay_2.addWidget(self.spin_box)
        lay_2.addStretch()
        button_1 = MPushButton(text='Run')
        button_1.clicked.connect(self.run)

        main_lay = QtWidgets.QVBoxLayout()
        main_lay.addWidget(MDivider(u'选择文件夹'))
        main_lay.addLayout(lay_1)
        main_lay.addWidget(MDivider(u'选择Doc文档'))
        main_lay.addWidget(table_default)
        main_lay.addWidget(MDivider(u'用户操作'))
        main_lay.addLayout(lay_2)
        main_lay.addWidget(button_1)

        self.setLayout(main_lay)
        geo = QApplication.desktop().screenGeometry()
        self.setGeometry(geo.width() / 4, geo.height() / 5, geo.width() / 5, geo.height() / 4)

    def GetFolder(self):
        docx_list = []
        data_list = []
        for root, dirs, files in os.walk(self.label_1.text()):
            for f in files:
                if os.path.splitext(f)[-1] == '.docx':
                    docx_list.append(os.path.join(root, f))

        for i in docx_list:
            docx_dic = {}
            docx_dic['docx_path'] = i
            docx_dic['docx_name'] = os.path.basename(i).split('.')[0]
            docx_dic['docx_name_checked'] = 2
            data_list.append(docx_dic)
        self.model_1.set_data_list(data_list)

    def run(self):
        epi_time = self.spin_box.value()
        check_docx_list = []

        # 创建输出结果的Excel到目标文件夹中
        row_shot = 0  # 镜头表的行
        row_asset = 0  # 资产表的行
        xlspath = self.label_1.text() + u'/拆分结果.xlsx'
        workbook = xlsxwriter.Workbook(xlspath)  # 新建一个Excel表
        worksheet1 = workbook.add_worksheet('Shot')  # 新建Shot表
        worksheet2 = workbook.add_worksheet('Asset')  # 新建Asset表

        # 定义样式
        bold_format = workbook.add_format({'bold': True, 'font_size': 14, 'bg_color': 'yellow'})
        # 填写 Shot 表头信息，并应用样式
        shot_headers = ['', '', u'集数', u'场号',u'日夜', u'内外', u'剧情地点', u'人物', '', '', '', u'级别', u'占比', u'分钟数', u'描述']
        for col, s_header in enumerate(shot_headers):
            worksheet1.write(0, col, s_header, bold_format)

        # 填写 Shot 表头信息，并应用样式
        assets_headers = [u'集数', u'场号',u'日夜', u'内外', u'剧情地点', '', '', u'描述', '', '', u'级别']
        for col, a_header in enumerate(assets_headers):
            worksheet2.write(0, col, a_header, bold_format)

        # 分级所需存储空间
        # 镜头和资产对应的颜色列表，用于判断当前字体是否应该存储到写入列表中
        shot_level_colorlist = ['9900CC_None', 'A50021_None', 'CC9900_None', '006600_None',
                                '006699_None', '3333FF_None']
        asset_level_colorlist = ['PINK (5)_None_None', 'RED (6)_None_None', 'YELLOW (7)_None_None',
                                 'BRIGHT_GREEN (4)_None_None', 'TURQUOISE (3)_None_None', 'GRAY_25 (16)_None_None']
        # 镜头等级对应 字体颜色，下划线 资产等级对应 背景颜色，下划线，粗体是否
        shot_level_dic = {
            '9900CC_None': 'S',
            'A50021_None': 'A',
            'CC9900_None': 'B',
            '006600_None': 'C',
            '006699_None': 'D',
            '3333FF_None': 'E'
        }
        asset_level_dic = {
            'PINK (5)_None_None': 'S',
            'RED (6)_None_None': 'A',
            'YELLOW (7)_None_None': 'B',
            'BRIGHT_GREEN (4)_None_None': 'C',
            'TURQUOISE (3)_None_None': 'D',
            'GRAY_25 (16)_None_None': 'E'
        }

        # 用于排序的列表
        level_list = ['S', 'A', 'B', 'C', 'D', 'E']
        scene_list = ['TURQUOISE (3)_None_True', 'DARK_RED (13)_None_True', 'GREEN (11)_None_True',
                      'PINK (5)_None_True', 'TEAL (10)_None_True']
        # 使用一个嵌套的镜头字典来存储对应镜头级别所获取的内容，嵌套字典的好处是可以在一个'```'的识别下，存储多个同级别的镜头和资产
        shot_dic = {
            'S': {},
            'A': {},
            'B': {},
            'C': {},
            'D': {},
            'E': {}
        }

        # 使用一个嵌套的资产字典来存储对应资产级别所获取的内容
        asset_dic = {
            'S': {},
            'A': {},
            'B': {},
            'C': {},
            'D': {},
            'E': {}
        }

        # 使用场次字典来获取对应场次的 场景号 人物 景时等信息， 使用背景颜色 粗体 下划线 来获取
        scene_dic = {
            'TURQUOISE (3)_None_True': [],  # 场次号
            'PINK (5)_None_True': [],  # 场景名
            'TEAL (10)_None_True': [],  # 人物
            'GREEN (11)_None_True': [],  # 内外景
            'DARK_RED (13)_None_True': [],  # 时间点
        }

        # 定义镜头和资产级别，通过颜色来获取，可以将获取的内容存储到正确级别的字典里面
        shot_level = ''
        asset_level = ''
        # 定义两个列表来获取当前的镜头和资产，当遇到^ &的时候，根据shot_level和asset_level存入指定的字典中
        current_shot_list = []
        current_asset_list = []
        #获取集数，每个docx只有一个
        epi = []
        element = [] # Excel写入需要一个列表，可以在此列表中调整写入顺序(按排写入)
        shot_index = 1
        asset_index = 1
        custom_info = []
        shot_custom_dic = {}
        asset_custom_dic = {}

        # 自定义信息使用正则表达式从对应的custom_info中读取
        shot_vfx = re.compile('VFX:(.*?)\*')
        shot_note = re.compile('ShotNote:(.*?)\*')
        shot_sure = re.compile('Sure:(.*?)\*')
        shot_info_dic = {
            'VFX': [],
            'Note': [],
            'Sure': []
        }
        asset_name = re.compile('Name:(.*?)\*')
        asset_vfx = re.compile('VFXType:(.*?)\*')
        asset_num = re.compile('Num:(.*?)\*')
        asset_unit = re.compile('Unit:(.*?)\*')
        asset_note = re.compile('AssetNote:(.*?)\*')
        asset_scan = re.compile('Scan:(.*?)\*')
        asset_md = re.compile('MD:(.*?)\*')
        asset_info_dic = {
            'Name': [],
            'VFXType': [],
            'Num': [],
            'Unit': [],

            'Note': [],
            'Scan': [],
            'MD': []
        }

        # 获取选择的docx文件
        for doc_data in self.model_1.get_data_list():
            if doc_data['docx_name_checked'] == 2:
                check_docx_list.append(doc_data['docx_path'])
        # 排序列表，可识别数字
        sort_docx_list = sorted(check_docx_list)

        # 循环排序后的列表，对每个文件进行操作
        for doc in sort_docx_list:
            #定义每一集的字总数
            all_text = []
            # 将当前路径的docx文件转换为docx库的对象
            current_file = docx.Document(doc)
            # 获取每一个段落对象（基本上是按照换行符分段）
            for i in current_file.paragraphs:
                # 获取段落中每一个部分对象
                for r in i.runs:
                    # 在第一次循环中获取集数
                    if r.font.highlight_color == WD_COLOR_INDEX.GRAY_50 and r.font.underline == None and r.font.bold == True:
                        epi.append(r.text)
                    # 如果这个部分的下划线属性为空，则说明是原生字体，我们规则中使用下划线来定义需要编辑的属性，不能获取到原文中
                    if r.font.underline == None:
                        # 将原文的文字添加达到all_text列表中，用于统计数据（获取的是一段字）
                        all_text.append(r.text)
            # 循环all_text列表中的每一段，以此来获取全文总字数
            all_text_str = ''
            for a in all_text:
                all_text_str = all_text_str + a
            text_len = float(len(all_text_str.replace(' ', '')))
            # print text_len

            for para in current_file.paragraphs:
                for clip in para.runs:
                    # 将各种判断使用.join连接为字符串，来对比字符串和字典的键，就能起到循环判定是否符合需求，这是一种使用空间换时间的优化。
                    shot_sign = '_'.join([str(clip.font.color.rgb), str(clip.font.underline)])
                    asset_sign = '_'.join([str(clip.font.highlight_color), str(clip.font.bold), str(clip.font.underline)])
                    scene_sign = '_'.join([str(clip.font.highlight_color), str(clip.font.underline), str(clip.font.bold)])
                    cus_info = '_'.join([str(clip.font.color.rgb), str(clip.font.underline)])
                    # 根据当前字体的格式来判断当前的镜头和资产等级,下文代码获取了场次信息和各级别的镜头和资产
                    for k, v in scene_dic.items():
                        if scene_sign == k:
                            v.append(clip.text)
                    if shot_sign in shot_level_colorlist:
                        shot_level = shot_level_dic[shot_sign]
                        current_shot_list.append(clip.text)
                    if asset_sign in asset_level_colorlist:
                        asset_level = asset_level_dic[asset_sign]
                        current_asset_list.append(clip.text)
                    if cus_info == 'C0C0C0_True':
                        custom_info.append(clip.text)
                    if '^' in clip.text:
                        # 当遇见关键字的时候，就可以判定一个镜头或者资产已经识别完毕，可以将对应的信息存储到嵌套字典中，
                        # 对应的序号可以正确识别镜头/资产和对应的用户信息
                        shot_dic[shot_level][shot_index] = current_shot_list
                        current_shot_list = []
                        shot_custom_dic[shot_index] = custom_info
                        custom_info = []
                        shot_index += 1
                    if '&' in clip.text:
                        # print 1,clip.text,epi
                        asset_dic[asset_level][asset_index] = current_asset_list
                        current_asset_list = []
                        asset_custom_dic[asset_index] = custom_info
                        custom_info = []
                        asset_index += 1
                    # 当识别到'```'关键字时，说明剧本进入了新的一场，即可将上面获取的场次，镜头，资产，自定信息，全部按照需求的格式存入excel
                    if '```' in clip.text:
                        # 循环镜头等级，获取每个镜头字典内的值
                        for shotlevel in level_list:
                            # 如果存在当前等级则进入循环
                            if shot_dic[shotlevel]:
                                # 循环当前等级字典内的字典，以获取同级的不同镜头（index是判断的基础）
                                for k in shot_dic[shotlevel]:
                                    # 将当前序号的镜头对应的自定义信息连接成字符串，再使用正则表达式获取
                                    shot_string1 = ''
                                    for shot_str in shot_dic[shotlevel][k]:
                                        shot_string1 = shot_string1 + shot_str
                                    shot_len1 = float(len(shot_string1.replace(' ', '')))
                                    shot_info = ''.join(shot_custom_dic[k])
                                    match_shot_vfx = re.findall(shot_vfx, shot_info)
                                    match_shot_note = re.findall(shot_note, shot_info)
                                    match_shot_sure = re.findall(shot_sure, shot_info)
                                    shot_info_dic['VFX'] = match_shot_vfx
                                    shot_info_dic['Note'] = match_shot_note
                                    shot_info_dic['Sure'] = match_shot_sure
                                    element.append(' ')
                                    element.append(' ')
                                    element.append(''.join(epi))
                                    for scene in scene_list:
                                        element.append(''.join(scene_dic[scene]))
                                    element.append(' ')
                                    element.append(' ')
                                    element.append(' ')
                                    element.append(shotlevel)
                                    element.append(
                                        '%.2f%%' % ((round(shot_len1 / text_len, 5)) * 100))
                                    element.append(round(shot_len1 / text_len * epi_time, 5))
                                    element.append(''.join(shot_dic[shotlevel][k]))
                                    element.append(''.join(shot_info_dic['VFX']))
                                    element.append(''.join(shot_info_dic['Note']))
                                    element.append(''.join(shot_info_dic['Sure']))
                                    for col, item in enumerate(element):
                                        worksheet1.write(row_shot+1, col, item)
                                    row_shot += 1
                                    shot_info_dic['VFX'] = []
                                    shot_info_dic['Note'] = []
                                    shot_info_dic['Sure'] = []
                                    element = []

                        # 循环资产等级，获取每个资产对应的值
                        for assetlevel in level_list:
                            if asset_dic[assetlevel]:
                                for ak in asset_dic[assetlevel]:
                                    # 将资产自定义信息连接成一个字符串方便正则表达式获取对应值
                                    asset_info = ''.join(asset_custom_dic[ak])
                                    match_asset_name = re.findall(asset_name, asset_info)
                                    match_asset_vfxtype = re.findall(asset_vfx, asset_info)
                                    match_asset_num = re.findall(asset_num, asset_info)
                                    match_asset_unit = re.findall(asset_unit, asset_info)
                                    match_asset_note = re.findall(asset_note, asset_info)
                                    match_asset_sacn = re.findall(asset_scan, asset_info)
                                    match_asset_md = re.findall(asset_md, asset_info)
                                    asset_info_dic['Name'] = match_asset_name
                                    asset_info_dic['VFXType'] = match_asset_vfxtype
                                    asset_info_dic['Num'] = match_asset_num
                                    asset_info_dic['Unit'] = match_asset_unit
                                    asset_info_dic['Note'] = match_asset_note
                                    asset_info_dic['Scan'] = match_asset_sacn
                                    asset_info_dic['MD'] = match_asset_md

                                    element.append(''.join(epi))
                                    element.append(''.join(scene_dic['TURQUOISE (3)_None_True']))
                                    element.append(''.join(scene_dic['DARK_RED (13)_None_True']))
                                    element.append(''.join(scene_dic['GREEN (11)_None_True']))
                                    element.append(''.join(scene_dic['PINK (5)_None_True']))
                                    element.append(' ')
                                    element.append(' ')
                                    element.append(''.join(asset_dic[assetlevel][ak]))
                                    element.append(''.join(asset_info_dic['Name']))
                                    element.append(''.join(asset_info_dic['VFXType']))
                                    element.append(assetlevel)
                                    element.append(''.join(asset_info_dic['Num']))
                                    element.append(''.join(asset_info_dic['Unit']))
                                    element.append(''.join(asset_info_dic['Note']))
                                    element.append(''.join(asset_info_dic['Scan']))
                                    element.append(''.join(asset_info_dic['MD']))
                                    for col, item in enumerate(element):
                                        worksheet2.write(row_asset + 1, col, item)
                                    row_asset += 1
                                    asset_info_dic['Name'] = []
                                    asset_info_dic['VFXType'] = []
                                    asset_info_dic['Num'] = []
                                    asset_info_dic['Unit'] = []
                                    asset_info_dic['Note'] = []
                                    asset_info_dic['Scan'] = []
                                    asset_info_dic['MD'] = []
                                    element = []

                        # 循环完后初始化场次信息
                        shot_index = 1
                        asset_index = 1
                        scene_dic = {
                            'TURQUOISE (3)_None_True': [],  # 场次号
                            'PINK (5)_None_True': [],  # 场景名
                            'TEAL (10)_None_True': [],  # 人物
                            'GREEN (11)_None_True': [],  # 内外景
                            'DARK_RED (13)_None_True': [],  # 时间点
                        }
                        # 初始化镜头
                        shot_dic = {
                            'S': {},
                            'A': {},
                            'B': {},
                            'C': {},
                            'D': {},
                            'E': {}
                        }

                        # 初始化资产
                        asset_dic = {
                            'S': {},
                            'A': {},
                            'B': {},
                            'C': {},
                            'D': {},
                            'E': {}
                        }

        # 最后一个段落，由于没有下一个'```'关键字，所以不会输出，故我们需要单独输出一次
            for shotlevel in level_list:
                # 如果存在当前等级则进入循环
                if shot_dic[shotlevel]:
                    # 循环当前等级字典内的字典，以获取同级的不同镜头（index是判断的基础）
                    for k in shot_dic[shotlevel]:
                        # 将当前序号的镜头对应的自定义信息连接成字符串，再使用正则表达式获取
                        shot_string = ''
                        for shot_str in shot_dic[shotlevel][k]:
                            shot_string = shot_string + shot_str
                        shot_len = float(len(shot_string.replace(' ', '')))
                        shot_info = ''.join(shot_custom_dic[k])
                        match_shot_vfx = re.findall(shot_vfx, shot_info)
                        match_shot_note = re.findall(shot_note, shot_info)
                        match_shot_sure = re.findall(shot_sure, shot_info)
                        shot_info_dic['VFX'] = match_shot_vfx
                        shot_info_dic['Note'] = match_shot_note
                        shot_info_dic['Sure'] = match_shot_sure
                        element.append(' ')
                        element.append(' ')
                        element.append(''.join(epi))
                        for scene in scene_list:
                            element.append(''.join(scene_dic[scene]))
                        element.append(' ')
                        element.append(' ')
                        element.append(' ')
                        element.append(shotlevel)
                        element.append(
                            '%.2f%%' % ((round(shot_len / text_len, 5)) * 100))
                        element.append(round(shot_len / text_len * epi_time, 5))
                        element.append(''.join(shot_dic[shotlevel][k]))
                        element.append(''.join(shot_info_dic['VFX']))
                        element.append(''.join(shot_info_dic['Note']))
                        element.append(''.join(shot_info_dic['Sure']))
                        for col, item in enumerate(element):
                            worksheet1.write(row_shot+1, col, item)
                        row_shot += 1
                        shot_info_dic['VFX'] = []
                        shot_info_dic['Note'] = []
                        shot_info_dic['Sure'] = []
                        element = []

            # 循环资产等级，获取每个资产对应的值j
            for assetlevel in level_list:
                if asset_dic[assetlevel]:
                    for ak in asset_dic[assetlevel]:
                        asset_info = ''.join(asset_custom_dic[ak])
                        match_asset_name = re.findall(asset_name, asset_info)
                        match_asset_vfxtype = re.findall(asset_vfx, asset_info)
                        match_asset_num = re.findall(asset_num, asset_info)
                        match_asset_unit = re.findall(asset_unit, asset_info)
                        match_asset_note = re.findall(asset_note, asset_info)
                        match_asset_sacn = re.findall(asset_scan, asset_info)
                        match_asset_md = re.findall(asset_md, asset_info)
                        asset_info_dic['Name'] = match_asset_name
                        asset_info_dic['VFXType'] = match_asset_vfxtype
                        asset_info_dic['Num'] = match_asset_num
                        asset_info_dic['Unit'] = match_asset_unit
                        asset_info_dic['Note'] = match_asset_note
                        asset_info_dic['Scan'] = match_asset_sacn
                        asset_info_dic['MD'] = match_asset_md

                        element.append(''.join(epi))
                        element.append(''.join(scene_dic['TURQUOISE (3)_None_True']))
                        element.append(''.join(scene_dic['DARK_RED (13)_None_True']))
                        element.append(''.join(scene_dic['GREEN (11)_None_True']))
                        element.append(''.join(scene_dic['PINK (5)_None_True']))
                        element.append(' ')
                        element.append(' ')
                        element.append(''.join(asset_dic[assetlevel][ak]))
                        element.append(''.join(asset_info_dic['Name']))
                        element.append(''.join(asset_info_dic['VFXType']))
                        element.append(assetlevel)
                        element.append(''.join(asset_info_dic['Num']))
                        element.append(''.join(asset_info_dic['Unit']))
                        element.append(''.join(asset_info_dic['Note']))
                        element.append(''.join(asset_info_dic['Scan']))
                        element.append(''.join(asset_info_dic['MD']))
                        for col, item in enumerate(element):
                            worksheet2.write(row_asset + 1, col, item)
                        row_asset += 1
                        asset_info_dic['Name'] = []
                        asset_info_dic['VFXType'] = []
                        asset_info_dic['Num'] = []
                        asset_info_dic['Unit'] = []
                        asset_info_dic['Note'] = []
                        asset_info_dic['Scan'] = []
                        asset_info_dic['MD'] = []
                        element = []
            epi = []
            # 循环完后初始化场次信息
            shot_index = 1
            asset_index = 1
            scene_dic = {
                'TURQUOISE (3)_None_True': [],  # 场次号
                'PINK (5)_None_True': [],  # 场景名
                'TEAL (10)_None_True': [],  # 人物
                'GREEN (11)_None_True': [],  # 内外景
                'DARK_RED (13)_None_True': [],  # 时间点
            }
            # 初始化镜头
            shot_dic = {
                'S': {},
                'A': {},
                'B': {},
                'C': {},
                'D': {},
                'E': {}
            }

            # 初始化资产
            asset_dic = {
                'S': {},
                'A': {},
                'B': {},
                'C': {},
                'D': {},
                'E': {}
            }
        workbook.close()
        QMessageBox.information(self, u"提示", u'运行结束', QMessageBox.Yes)

if __name__ == '__main__':
    from dayu_widgets import dayu_theme
    from dayu_widgets.qt import application

    with application() as app:
        test = ScriptSplit()
        dayu_theme.apply(test)
        test.show()
